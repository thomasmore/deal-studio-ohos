# Vera shared Qwen prototype

The included Apple Silicon macOS runner loads one tokenizer and one compressed Qwen table for UI selection and Vera arithmetic formula generation. Formula generation supports up to two operations. The phone build is still experimental.

From the extracted directory, run `./local-jev-shared bundle < example.jsonl`. The runner prints a ready frame followed by the response. It also accepts Jev-shaped `state` and `questions` requests in the same `id` and `request` envelope.

The tokenizer and token embeddings come from Qwen2.5-Coder-0.5B-Instruct under Apache-2.0. The embedding table was projected to 96 dimensions and quantized to 8 bits. The UI scorer and formula decoder were trained for Vera.
